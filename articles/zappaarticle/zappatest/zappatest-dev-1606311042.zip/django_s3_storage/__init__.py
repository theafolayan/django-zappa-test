"""
Django Amazon S3 file storage.
"""


__version__ = (0, 13, 4)
