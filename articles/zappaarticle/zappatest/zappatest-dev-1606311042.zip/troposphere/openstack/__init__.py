# -*- coding: utf-8 -*-
"""
OpenStack
---------

The package to support OpenStack templates using troposphere.
"""
